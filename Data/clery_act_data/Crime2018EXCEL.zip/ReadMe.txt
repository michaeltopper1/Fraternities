
**************************************************************************
              ReadMe file for Campus Safety and Security 2018
                                          
              Prepared by IT Innovative Solutions - Feb 12, 2019 
**************************************************************************


Crime2018EXCEL.zip contains the following files:

        Noncampusarrest151617.xls           -- noncampus arrest data for year 2015, year 2016 and 2017
        Noncampuscrime151617.xls            -- noncampus criminal offenses data for year 2015, year 2016 and 2017
        Noncampusdiscipline151617.xls       -- noncampus disciplinary actions data for year 2015, year 2016 and 2017
        Noncampushate151617.xlsx            -- noncampus hate crimes data for year 2015, year 2016 and 2017
        Noncampusvawa151617.xls             -- noncampus vawa offenses data for year 2015, year 2016 and 2017
        Oncampusarrest151617.xls            -- on-campus arrest data for year 2015, year 2016 and 2017
        Oncampuscrime151617.xls             -- on-campus criminal offenses data for year 2015, year 2016 and 2017
        Oncampusdiscipline151617.xls        -- on-campus disciplinary actions data for year 2015, year 2016 and 2017
        Oncampushate151617.xlsx             -- on-campus hate crimes data for year 2015, year 2016 and 2017
        Oncampusvawa151617.xls              -- on-campus vawa offenses data for year 2015, year 2016 and 2017
        Publicpropertyarrest151617.xls      -- public property arrest data for year 2015, year 2016 and 2017
        Publicpropertycrime151617.xls       -- public property criminal offenses data for year 2015, year 2016 and 2017
        Publicpropertydiscipline151617.xls  -- public property disciplinary actions data for year 2015, year 2016 and 2017
        Publicpropertyhate151617.xlsx       -- public property hate crimes data for year 2015, year 2016 and 2017
        Publicpropertyvawa151617.xls        -- public property vawa offenses data for year 2015, year 2016 and 2017
        Reportedarrest151617.xls            -- reported by local police arrest data for year 2015, year 2016 and 2017
        Reportedcrime151617.xls             -- reported by local police criminal offenses data for year 2015, year 2016 and 2017
        Reporteddiscipline151617.xls        -- reported by local police disciplinary actions data for year 2015, year 2016 and 2017
        Reportedhate151617.xlsx             -- reported by local police hate crimes data for year 2015, year 2016 and 2017
        Reportedvawa151617.xls              -- reported by local police vawa offenses data for year 2015, year 2016 and 2017
        Residencehallarrest151617.xls       -- residence hall arrest data for year 2015, year 2016 and 2017
        Residencehallcrime151617.xls        -- residence hall criminal offenses data for year 2015, year 2016 and 2017
        Residencehalldiscipline151617.xls   -- residence hall disciplinary actions data for year 2015, year 2016 and 2017
        Residencehallhate151617.xlsx        -- residence hall hate crimes data for year 2015, year 2016 and 2017
        Residencehallvawa151617.xls         -- residence hall vawa offenses data for year 2015, year 2016 and 2017
	Residencehallfire15.xls             -- residence hall fire data for year 2015
        Residencehallfire16.xls             -- residence hall fire data for year 2016
	Residencehallfire17.xls             -- residence hall fire data for year 2017
	Unfounded151617.xls                 -- unfounded crimes data for year 2015, year 2016 and 2017
	
      

Data Dictionaries for Each Excel File
        Noncampusarrest151617_Doc.doc         
        Noncampuscrime151617_Doc.doc                  
        Noncampusdiscipline151617_Doc.doc             
        Noncampushate151617_Doc.doc                   
        Noncampusvawa151617_Doc.doc                   
        Oncampusarrest151617_Doc.doc                  
        Oncampuscrime151617_Doc.doc                   
        Oncampusdiscipline151617_Doc.doc              
        Oncampushate151617_Doc.doc                    
        Oncampusvawa151617_Doc.doc                    
        Publicpropertyarrest151617_Doc.doc            
        Publicpropertycrime151617_Doc.doc             
        Publicpropertydiscipline151617_Doc.doc        
        Publicpropertyhate151617_Doc.doc              
        Publicpropertyvawa151617_Doc.doc              
        Reportedarrest151617_Doc.doc                  
        Reportedcrime151617_Doc.doc                   
        Reporteddiscipline151617_Doc.doc              
        Reportedhate151617_Doc.doc                    
        Reportedvawa151617_Doc.doc                    
        Residencehallarrest151617_Doc.doc             
        Residencehallcrime151617_Doc.doc              
        Residencehalldiscipline151617_Doc.doc         
        Residencehallhate151617_Doc.doc               
        Residencehallvawa151617_Doc.doc               
	Residencehallfire13_Doc.doc                   
        Residencehallfire14_Doc.doc                   
	Residencehallfire15_Doc.doc                   
	Unfounded151617_Doc.doc                       
        
           
   __________________________________________________________________________ 

