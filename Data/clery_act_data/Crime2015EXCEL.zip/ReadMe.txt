
**************************************************************************
              ReadMe file for Campus Safety and Security 2015
                                          
              Prepared by IT Innovative Solutions - DEC 11, 2015 
**************************************************************************


Crime2015EXCEL.zip contains the following files:

        Noncampusarrest121314.xls           -- noncampus arrest data for year 2012, year 2013 and 2014
        Noncampuscrime121314.xls            -- noncampus criminal offenses data for year 2012, year 2013 and 2014
        Noncampusdiscipline121314.xls       -- noncampus disciplinary actions data for year 2012, year 2013 and 2014
        Noncampushate121314.xlsx            -- noncampus hate crimes data for year 2012, year 2013 and 2014
        Noncampusvawa121314.xls             -- noncampus vawa offenses data for year 2012, year 2013 and 2014
        Oncampusarrest121314.xls            -- on-campus arrest data for year 2012, year 2013 and 2014
        Oncampuscrime121314.xls             -- on-campus criminal offenses data for year 2012, year 2013 and 2014
        Oncampusdiscipline121314.xls        -- on-campus disciplinary actions data for year 2012, year 2013 and 2014
        Oncampushate121314.xlsx             -- on-campus hate crimes data for year 2012, year 2013 and 2014
        Oncampusvawa121314.xls              -- on-campus vawa offenses data for year 2012, year 2013 and 2014
        Publicpropertyarrest121314.xls      -- public property arrest data for year 2012, year 2013 and 2014
        Publicpropertycrime121314.xls       -- public property criminal offenses data for year 2012, year 2013 and 2014
        Publicpropertydiscipline121314.xls  -- public property disciplinary actions data for year 2012, year 2013 and 2014
        Publicpropertyhate121314.xlsx       -- public property hate crimes data for year 2012, year 2013 and 2014
        Publicpropertyvawa121314.xls        -- public property vawa offenses data for year 2012, year 2013 and 2014
        Reportedarrest121314.xls            -- reported by local police arrest data for year 2012, year 2013 and 2014
        Reportedcrime121314.xls             -- reported by local police criminal offenses data for year 2012, year 2013 and 2014
        Reporteddiscipline121314.xls        -- reported by local police disciplinary actions data for year 2012, year 2013 and 2014
        Reportedhate121314.xlsx             -- reported by local police hate crimes data for year 2012, year 2013 and 2014
        Reportedvawa121314.xls              -- reported by local police vawa offenses data for year 2012, year 2013 and 2014
        Residencehallarrest121314.xls       -- residence hall arrest data for year 2012, year 2013 and 2014
        Residencehallcrime121314.xls        -- residence hall criminal offenses data for year 2012, year 2013 and 2014
        Residencehalldiscipline121314.xls   -- residence hall disciplinary actions data for year 2012, year 2013 and 2014
        Residencehallhate121314.xlsx        -- residence hall hate crimes data for year 2012, year 2013 and 2014
        Residencehallvawa121314.xls         -- residence hall vawa offenses data for year 2012, year 2013 and 2014
	Residencehallfire12.xls             -- residence hall fire data for year 2012
        Residencehallfire13.xls             -- residence hall fire data for year 2013
	Residencehallfire14.xls             -- residence hall fire data for year 2014
	Unfounded121314.xls                 -- unfounded crimes data for year 2012, year 2013 and 2014
	
      

Data Dictionaries for Each Excel File
        Noncampusarrest121314_Doc.doc         
        Noncampuscrime121314_Doc.doc                  
        Noncampusdiscipline121314_Doc.doc             
        Noncampushate121314_Doc.doc                   
        Noncampusvawa121314_Doc.doc                   
        Oncampusarrest121314_Doc.doc                  
        Oncampuscrime121314_Doc.doc                   
        Oncampusdiscipline121314_Doc.doc              
        Oncampushate121314_Doc.doc                    
        Oncampusvawa121314_Doc.doc                    
        Publicpropertyarrest121314_Doc.doc            
        Publicpropertycrime121314_Doc.doc             
        Publicpropertydiscipline121314_Doc.doc        
        Publicpropertyhate121314_Doc.doc              
        Publicpropertyvawa121314_Doc.doc              
        Reportedarrest121314_Doc.doc                  
        Reportedcrime121314_Doc.doc                   
        Reporteddiscipline121314_Doc.doc              
        Reportedhate121314_Doc.doc                    
        Reportedvawa121314_Doc.doc                    
        Residencehallarrest121314_Doc.doc             
        Residencehallcrime121314_Doc.doc              
        Residencehalldiscipline121314_Doc.doc         
        Residencehallhate121314_Doc.doc               
        Residencehallvawa121314_Doc.doc               
	Residencehallfire12_Doc.doc                   
        Residencehallfire13_Doc.doc                   
	Residencehallfire14_Doc.doc                   
	Unfounded121314_Doc.doc                       
        
           
   __________________________________________________________________________ 

